# Group 4 | CloudNine Systems | Milestone 2

Open `output/pdf/Group4_Milestone2.pdf` for the implementation summary, the nine
query interpretations and both interface mockups.

- **DDL and DML:** `sql/milestone2/01_schema.sql` and `sql/milestone2/02_seed.sql`
- **Proposed queries:** `sql/milestone2/03_queries.sql`
- **Executed query evidence:** `docs/milestone2/Group4_Query_Evidence.md`
- **Initial export:** `output/db/Group4_Initial_Export.sql`
- **Populated SQLite database:** `output/db/Group4_Initial_Export.sqlite3`
- **Web wireframe:** Open `docs/milestone2/Group4_Wireframe.html` and choose
  Operations or Billing.
- **Restore and run instructions:** `docs/milestone2/Group4_Milestone2.md`

The database represents synthetic activity from May through October 2026.
